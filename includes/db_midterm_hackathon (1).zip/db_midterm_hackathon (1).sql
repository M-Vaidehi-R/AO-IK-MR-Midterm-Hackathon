-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 20, 2022 at 02:13 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_midterm_hackathon`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

DROP TABLE IF EXISTS `tbl_category`;
CREATE TABLE IF NOT EXISTS `tbl_category` (
  `category_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `category_name` varchar(250) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`category_id`, `category_name`) VALUES
(1, 'Thermostat-Security');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_colours`
--

DROP TABLE IF EXISTS `tbl_colours`;
CREATE TABLE IF NOT EXISTS `tbl_colours` (
  `colour_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `colour_name` varchar(150) NOT NULL,
  `product_price_id` tinyint(3) UNSIGNED NOT NULL,
  PRIMARY KEY (`colour_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_colours`
--

INSERT INTO `tbl_colours` (`colour_id`, `colour_name`, `product_price_id`) VALUES
(1, 'Black', 2),
(2, 'White', 1),
(3, 'Grey', 1),
(4, 'Blue', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_images`
--

DROP TABLE IF EXISTS `tbl_images`;
CREATE TABLE IF NOT EXISTS `tbl_images` (
  `product_image_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_image_name` varchar(250) NOT NULL,
  `colour_id` tinyint(3) NOT NULL,
  PRIMARY KEY (`product_image_id`),
  KEY `colour_id` (`colour_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_images`
--

INSERT INTO `tbl_images` (`product_image_id`, `product_image_name`, `colour_id`) VALUES
(1, 'black.jpg', 1),
(2, 'white.jpg', 2),
(3, 'grey.jpg', 3),
(4, 'blue.jpg', 4);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_desc`
--

DROP TABLE IF EXISTS `tbl_product_desc`;
CREATE TABLE IF NOT EXISTS `tbl_product_desc` (
  `product_desc_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_desc` text NOT NULL,
  PRIMARY KEY (`product_desc_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product_desc`
--

INSERT INTO `tbl_product_desc` (`product_desc_id`, `product_desc`) VALUES
(1, 'Select the best and affordable Thermostat devices for your home from the best manufacturers, who provide a 3 year warranty to any of their devices. Explore the various colours and choose the best one that suites your home. The enhanced Thermostat device automatically turns down the temperature when nobody is at home and automatically heats or cools your home when electricity is more affordable and cleaner. Enjoy 10% off on any devices that you purchase, offer valid till Oct 31st 2022. Grab yours Now!');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_name`
--

DROP TABLE IF EXISTS `tbl_product_name`;
CREATE TABLE IF NOT EXISTS `tbl_product_name` (
  `product_name_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_name` varchar(150) NOT NULL,
  PRIMARY KEY (`product_name_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product_name`
--

INSERT INTO `tbl_product_name` (`product_name_id`, `product_name`) VALUES
(1, 'ThermoStat');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_price`
--

DROP TABLE IF EXISTS `tbl_product_price`;
CREATE TABLE IF NOT EXISTS `tbl_product_price` (
  `product_price_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_price` varchar(100) NOT NULL,
  PRIMARY KEY (`product_price_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product_price`
--

INSERT INTO `tbl_product_price` (`product_price_id`, `product_price`) VALUES
(1, '$299.99'),
(2, '$349.99');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_specifications`
--

DROP TABLE IF EXISTS `tbl_product_specifications`;
CREATE TABLE IF NOT EXISTS `tbl_product_specifications` (
  `product_spec_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_spec_desc` varchar(350) NOT NULL,
  PRIMARY KEY (`product_spec_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product_specifications`
--

INSERT INTO `tbl_product_specifications` (`product_spec_id`, `product_spec_desc`) VALUES
(1, 'Type'),
(2, 'Width'),
(3, 'Height'),
(4, 'Sensors'),
(5, 'Memory'),
(6, 'Power Consuption'),
(7, 'Connectivity');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tagline`
--

DROP TABLE IF EXISTS `tbl_tagline`;
CREATE TABLE IF NOT EXISTS `tbl_tagline` (
  `product_tagline_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_tagline` varchar(450) NOT NULL,
  PRIMARY KEY (`product_tagline_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_tagline`
--

INSERT INTO `tbl_tagline` (`product_tagline_id`, `product_tagline`) VALUES
(1, 'A solid Companion for all seasons');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
